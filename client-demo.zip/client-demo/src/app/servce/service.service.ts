import { Post } from './../models/Post';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { catchError } from 'rxjs/operators/catchError';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

@Injectable()
export class ServiceService {

  private API_PATH = 'http://localhost:8080/post';

  constructor(private http: HttpClient) { }

  private formatErrors(error: any) {
    return new ErrorObservable(error.error);
  }

  get(path: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.get(`${path}`, { params }).pipe(catchError(this.formatErrors));
  }

  post(path: string, body: Object = {}): Observable<any> {
    return this.http.post(
      `${path}`,
      JSON.stringify(body)
    ).pipe(catchError(this.formatErrors));
  }

  getAllNews(): Observable<Post[]> {
    return this.get(this.API_PATH + '/list');
  }

  favorite(id){
    return this.post(this.API_PATH + '/favorite/'+ id);
  }

  unfavorite(id){
    return this.post(this.API_PATH + '/unfavorite/' + id);
  }

}
