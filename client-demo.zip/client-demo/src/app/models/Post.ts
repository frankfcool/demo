export interface Post {
    id: string;
    title: string;
    author: string;
    favorited: boolean;
    favoritesCount: number;
  }