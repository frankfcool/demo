import { ServiceService } from './../servce/service.service';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';

import { Post } from '../models/Post';

@Component({
  selector: 'app-favorite-button',
  templateUrl: './favorite-button.component.html'
})
export class FavoriteButtonComponent {
  constructor(
    private service: ServiceService,
    private router: Router
  ) {}

  @Input() post: Post;
  @Output() toggle = new EventEmitter<boolean>();
  isSubmitting = false;

  toggleFavorite() {

    // Favorite the article if it isn't favorited yet
    if (!this.post.favorited) {
        return this.service.favorite(this.post.id)
        .subscribe(
          data => {
            this.toggle.emit(true);
          }
        );
    }else{
        return this.service.unfavorite(this.post.id).subscribe(
          data => {
            this.toggle.emit(false);
          }
        );
    }
  }
}
