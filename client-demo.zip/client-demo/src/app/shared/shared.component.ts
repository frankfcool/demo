import { Post } from './../models/Post';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html'
})
export class SharedComponent{

  @Input() post: Post;

  onToggleFavorite(favorited: boolean) {
    this.post['favorited'] = favorited;
    if (favorited) {
      this.post['favoritesCount']++;
    } else {
      this.post['favoritesCount']--;
    }
  }
}
