import { Post } from './../models/Post';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../servce/service.service'
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  results: Post[];

  constructor(private service: ServiceService) { }

  ngOnInit() {
    this.service.getAllNews().subscribe(data => {
      this.results = data;
    });
  }
}
