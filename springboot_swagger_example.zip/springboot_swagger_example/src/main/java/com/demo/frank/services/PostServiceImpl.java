package com.demo.frank.services;

import com.demo.frank.domain.Data;
import com.demo.frank.domain.Post;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


@Service
public class PostServiceImpl implements PostService {

    private RestTemplate restTemplate;

    public PostServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public Iterable<Post> listAllPosts() {
        Data data  = restTemplate.getForObject("http://localhost:3000/data", Data.class);
        return data.getPosts();
    }

    @Override
    public Post updateFavorite(String operation, Long id) {
        JSONParser parser = new JSONParser();
        FileWriter file = null;
        FileReader reader = null;
        Post postEntity = new Post();
        postEntity.setId(id);
        try {
            reader = new FileReader("/Users/fengzhenyu/Documents/fake-api/data.json");
            JSONObject json = (JSONObject) parser.parse(reader);
            JSONObject data = (JSONObject)json.get("data");
            JSONArray posts = (JSONArray)data.get("posts");
            JSONArray newPosts = new JSONArray();
            for(Object post: posts){
                if(post instanceof JSONObject){
                    JSONObject p = (JSONObject)post;
                    if((Long)p.get("id") == id){
                        Boolean favorited = (Boolean)p.get("favorited");
                        Long cnt =  (Long)p.get("favoritesCount");
                        if("favorite".equals(operation)){
                            p.put("favorited", true);
                            p.put("favoritesCount", cnt+1);
                        }else if("unfavorite".equals(operation) && cnt > 0){
                            p.put("favorited", false);
                            p.put("favoritesCount", cnt-1);
                        }
                        postEntity.setFavorited((Boolean)p.get("favorited"));
                        postEntity.setFavoritesCount((Long)p.get("favoritesCount"));
                        newPosts.add(p);
                    }else{
                        newPosts.add(p);
                    }
                }
            }

            data.put("posts", newPosts);
            json.put("data", data);

            file = new FileWriter("/Users/fengzhenyu/Documents/fake-api/data.json");
            file.write(json.toJSONString());

            /*posts.forEach(item -> {
                System.out.println("---------"+item);
                JSONObject post = (JSONObject)item;
                if((Long)post.get("id") == id){
                    Long cnt =  (Long)post.get("favoritesCount");
                    if("favorite".equals(operation)){
                        post.put("favoritesCount", cnt+1);
                    }else if("unfavorite".equals(operation) && cnt > 0){
                        post.put("favoritesCount", cnt-1);
                    }
                }
                newPosts.add(post);

            });*/

        }catch(IOException e){
            e.printStackTrace();
        }catch(ParseException e){
            e.printStackTrace();
        }finally {
            try{
                if(file != null) {
                    file.close();
                }
                if(reader != null){
                    reader.close();
                }
            }catch(IOException e){
                e.printStackTrace();
            }
        }

        return postEntity;
    }
}
