package com.demo.frank.domain;


public class Data {

    private Iterable<Post> posts = null;

    public Iterable<Post> getPosts() {
        return posts;
    }

    public void setPosts(Iterable<Post> posts) {
        this.posts = posts;
    }
}
