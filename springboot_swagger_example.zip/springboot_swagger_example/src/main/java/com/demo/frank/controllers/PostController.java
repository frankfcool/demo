package com.demo.frank.controllers;

import com.demo.frank.domain.Post;
import com.demo.frank.services.PostService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/post")
@Api(value="post", description="Operations to publish news")
public class PostController {

    @Autowired
    private PostService postService;

    @ApiOperation(value = "View a list of available posts",response = Post.class, responseContainer="List")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @RequestMapping(value = "/list", method= RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Post> list(){
        Iterable<Post> list = postService.listAllPosts();
        return list;
    }

    @ApiOperation(value = "Decrease favorite count")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Update favorite count successfully")
    })
    @RequestMapping(value = "/unfavorite/{id}", method = RequestMethod.POST, produces = "application/json")
    public Post updateUnFavoriteCnt(@PathVariable Long id){
        return postService.updateFavorite("unfavorite", id);
    }

    @ApiOperation(value = "Increase favorite count")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Update favorite count successfully")
    })
    @RequestMapping(value = "/favorite/{id}", method = RequestMethod.POST, produces = "application/json")
    public Post updateFavoriteCnt(@PathVariable Long id){
        return postService.updateFavorite("favorite", id);
    }

}
