package com.demo.frank.domain;

import io.swagger.annotations.ApiModelProperty;

public class Post {

    @ApiModelProperty(notes = "The post ID", required = true)
    private Long id;

    @ApiModelProperty(notes = "The post title", required = true)
    private String title;

    @ApiModelProperty(notes = "The post author")
    private String author;

    @ApiModelProperty(notes = "The favorited")
    private Boolean favorited;

    @ApiModelProperty(notes = "The favorites count")
    private Long favoritesCount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Boolean getFavorited() {
        return favorited;
    }

    public void setFavorited(Boolean favorited) {
        this.favorited = favorited;
    }

    public Long getFavoritesCount() {
        return favoritesCount;
    }

    public void setFavoritesCount(Long favoritesCount) {
        this.favoritesCount = favoritesCount;
    }

}
