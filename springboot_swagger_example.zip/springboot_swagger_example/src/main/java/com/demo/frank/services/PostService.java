package com.demo.frank.services;

import com.demo.frank.domain.Post;

import java.util.List;

public interface PostService {

    Iterable<Post> listAllPosts();

    Post updateFavorite(String operation, Long id);
}
